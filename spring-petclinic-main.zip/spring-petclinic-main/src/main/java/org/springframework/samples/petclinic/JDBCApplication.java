package org.springframework.samples.petclinic;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.springframework.samples.petclinic.owner.Owner;

public class JDBCApplication {

	public static void main(String[] args) {
		System.out.println("-------- Test de conexión con MySQL ------------");

		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			System.out.println("No encuentro el driver en el Classpath");
			e.printStackTrace();
			return;
		}

		System.out.println("Driver instalado y funcionando");
		Connection connection = null;
		Statement statement = null;
		try {
			connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/petclinic", "root", "root");
			if (connection != null) {
				System.out.println("Conexión establecida");
				/*
				 * System.out.println("CONSULTA 1");
				 * 
				 * statement=connection.createStatement(); String sql ="SELECT * FROM owners";
				 * ResultSet rs= statement.executeQuery(sql);
				 * 
				 * while(rs.next()) { int id=rs.getInt("id"); String
				 * firstName=rs.getString("first_name");
				 * 
				 * System.out.println("ID: "+ id); System.out.println("Nombre: "+ firstName);
				 * 
				 * }
				 * 
				 * 
				 * System.out.println("CONSULTA 2");
				 * 
				 * String sql2 =
				 * "INSERT INTO owners (first_name, last_name, address, city, telephone) "
				 * 
				 * +
				 * 
				 * "VALUES ('Alba', 'Blázquez', 'Cabeza de Vaca', 'Salamanca', '666666666')";
				 * 
				 * int numeroDeFilasModificadas = statement.executeUpdate(sql2);
				 * 
				 * System.out.print(numeroDeFilasModificadas);
				 * 
				 * 
				 * statement = connection.createStatement();
				 * 
				 * String sql = "UPDATE owners "
				 * 
				 * + "SET city = 'Sevilla'"
				 * 
				 * + "WHERE first_name = 'Marcos'";
				 * 
				 * int numeroDeFilasModificadas = statement.executeUpdate(sql);
				 */

				/*
				 * 4. Crear una variable de tipo String y buscar todos los dueños que coincidan
				 * // en nombre o apellido.
				 * 
				 * String sql =
				 * "SELECT * FROM owners WHERE first_name LIKE ? OR last_name LIKE ?"; String
				 * busqueda = "Da"; String termino = "%" + busqueda + "%"; PreparedStatement
				 * preparedStatement = connection.prepareStatement(sql);
				 * preparedStatement.setString(1, termino); preparedStatement.setString(2,
				 * termino); ResultSet rs = preparedStatement.executeQuery();
				 * 
				 * while (rs.next()) { int id = rs.getInt("id"); String firstName =
				 * rs.getString("first_name"); String lastName = rs.getString("last_name");
				 * 
				 * System.out.print("Id: " + id); System.out.print(", Nombre: " + firstName);
				 * System.out.println(", Apellidos: " + lastName); }
				 */

				// Parte del reto

				Owner dueño = new Owner();
				dueño.setFirstName("Alba");
				dueño.setLastName("Blazquez");
				dueño.setAddress("Calle cabeza de vaca");
				dueño.setCity("Salamanca");
				dueño.setTelephone("66666666");

				statement=connection.createStatement();
				
				String sq = "INSERT INTO owners (first_name, last_name, address, city, telephone) "

						+ dueño.getFirstName()+ dueño.getLastName()+dueño.getCity()+dueño.getAddress()+dueño.getTelephone();

				int numeroDeFilasModificadas = statement.executeUpdate(sq);

				System.out.print(numeroDeFilasModificadas);
				
				statement = connection.createStatement();
				 
				  String sql = "DELETE FROM owners WHERE first_name = 'Alba'";
				 
				 int eliminar = statement.executeUpdate(sql);
				 
				 System.out.print(eliminar);
				
				//rs.close();

			}

		} catch (SQLException e) {
			System.out.println("Connection Failed! Check output console");
			e.printStackTrace();
			return;
		} finally {
			try {
				if (statement != null)
					connection.close();
			} catch (SQLException se) {

			}
			try {
				if (connection != null)
					connection.close();
			} catch (SQLException se) {
				se.printStackTrace();
			}
		}
	}

}
