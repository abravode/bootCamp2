package org.springframework.samples.petclinic;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class JDBCApplication {

	public static void main(String[] args) {
		System.out.println("-------- Test de conexión con MySQL ------------");

		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			System.out.println("No encuentro el driver en el Classpath");
			e.printStackTrace();
			return;
		}

		System.out.println("Driver instalado y funcionando");
		Connection connection = null;
		Statement statement = null;
		PreparedStatement preparedStatement = null;
		try {
			connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/petclinic","root", "root");
			if (connection != null) {
				System.out.println("Conexión establecida");
				
				//Reto JDBC
				
				/*
				 * Crear un objeto de la clase Owner, rellenar tus datos personales 
				 * (o de tu compañero), y mediante JDBC parametrizado insertarte a ti 
				 * mismo como un propietario de mascotas. 
				 * Luego, si tienes mascota en casa, asígnate una mediante la clase Pet 
				 * y JDBC parametrizado, y por último, borra tus datos.
				 */
				
				
				/*
				 * Parte 1
				 * Inserción de mis datos en la Base de Datos
				 */
				String sqlJDBC = "INSERT INTO owners VALUES (null, ?, ?, ?, ?, ?)";
				String datos [] = {"Adrian","Bada","Mi direccion", "Leon", "777777777"};
				preparedStatement = connection.prepareStatement(sqlJDBC);
				preparedStatement.setString(1, datos[0]);
				preparedStatement.setString(2, datos[1]);
				preparedStatement.setString(3, datos[2]);
				preparedStatement.setString(4, datos[3]);
				preparedStatement.setString(5, datos[4]);
				
				int filas = preparedStatement.executeUpdate();
				System.out.println("Numero de datos insertados: "+filas);
				
				/*
				 * Parte 2
				 * Inserción de mi Mascota en la Base de Datos
				 */
				statement = connection.createStatement();
				
				String idOwner = "Select id FROM owners WHERE first_name='Adrian'";
				ResultSet rsIdOwner = statement.executeQuery(idOwner);
				String id_Owner = "";
				while(rsIdOwner.next()){
					id_Owner = String.valueOf(rsIdOwner.getInt("id"));
				}
				rsIdOwner.close();
				String idType = "Select id FROM types WHERE name='dog'";
				
				ResultSet rsidType = statement.executeQuery(idType);
				
				String id_Type = "";
				while(rsidType.next()){
					id_Type = String.valueOf(rsidType.getInt("id"));
				}
				rsidType.close();
				
				String sqlJDBCMascota = "INSERT INTO pets VALUES (null, ?, ?, ?, ?)";
				
				String datosMascota [] = {"Urko", "2005-08-15", id_Type, id_Owner};
				
				preparedStatement = connection.prepareStatement(sqlJDBCMascota);
				preparedStatement.setString(1, datosMascota[0]);
				preparedStatement.setString(2, datosMascota[1]);
				preparedStatement.setString(3, datosMascota[2]);
				preparedStatement.setString(4, datosMascota[3]);
				
				int filas1 = preparedStatement.executeUpdate();
				System.out.println("Numero de datos insertados: "+filas1);
				
				/*
				 * Parte 3
				 * Eliminacion de mis datos de la Base de Datos
				 */
				
				String sqlEliminacionMascota= "Delete pets FROM pets INNER JOIN owners ON pets.owner_id = owners.id WHERE pets.name='Urko' ";
				preparedStatement = connection.prepareStatement(sqlEliminacionMascota);
				int filasEliminadasMascota = preparedStatement.executeUpdate();
				
				String sqlEliminacion= "DELETE FROM owners WHERE first_name = 'Adrian'";
				preparedStatement = connection.prepareStatement(sqlEliminacion);
				int filasEliminadas = preparedStatement.executeUpdate();
				
				System.out.println("Numero de datos eliminados: "+filasEliminadas);
				
				System.out.println("Numero de datos eliminados mascotas: "+filasEliminadasMascota);
	
			
				// Consulta filtrada
				statement = connection.createStatement();
				String sql = "SELECT * FROM owners WHERE first_name LIKE ? OR last_name LIKE ?";
				String busqueda = "Da";
				String termino = "%"+busqueda+"%";
				preparedStatement = connection.prepareStatement(sql);
				preparedStatement.setString(1, termino);
				preparedStatement.setString(2, termino);
				ResultSet rs1 = preparedStatement.executeQuery();
				while(rs1.next()){
				         int id = rs1.getInt("id");
				         String firstName = rs1.getString("first_name");
				         String lastName = rs1.getString("last_name");

				         System.out.print("Id: " + id);
				         System.out.print(", Nombre: " + firstName);
				         System.out.println(", Apellidos: " + lastName);
				}
			    rs1.close();
				
				//Consulta completa
				String sqlSelectAll = "SELECT * FROM owners";
				
				//Consulta de Modificacion de datos
				String sqlUpdate = "UPDATE owners "
				           + "SET city = 'Sevilla'"
				           + "WHERE first_name = 'Marcos'";
				
				//Consulta de inserción de datos
				String sqlInsert = "INSERT INTO owners (first_name, last_name, address, city, telephone) "
						+ 
						"VALUES ('Marcos', 'Ginel', 'Mi dirección', 'Mi ciudad', '666666666')";
				
								
				int numeroDeFilasModificadas = statement.executeUpdate(sqlInsert);
						
				int numeroDeFilasActualizadas = statement.executeUpdate(sqlUpdate);
				
				ResultSet rs = statement.executeQuery(sqlSelectAll);
				
				while (rs.next()) {
					int id= rs.getInt("id");
					String first_name= rs.getString("first_name");
					
					System.out.print("\nID: "+id);
					System.out.print(", Nombre: "+first_name);
					
				}
				rs.close();
				
				System.out.println("Numero de Filas Modificadas: "+numeroDeFilasModificadas);
				System.out.println("Numero de Filas Actualizadas: "+numeroDeFilasActualizadas);

			}
		} catch (SQLException e) {
			System.out.println("Connection Failed! Check output console");
			e.printStackTrace();
			return;
		} finally {
			try {
				if(statement != null)
					connection.close();
			} catch (SQLException se) {
		    	  
		    }
		    try {
		        if(connection != null)
		            connection.close();
		    } catch (SQLException se) {
		         	se.printStackTrace();
		    }
		}
	}

}